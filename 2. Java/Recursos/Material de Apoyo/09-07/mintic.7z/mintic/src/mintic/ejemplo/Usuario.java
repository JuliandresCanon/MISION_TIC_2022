package mintic.ejemplo;

/**
 *
 * @author farma
 */
public class Usuario {
    public String id,nombre,contrasena;
    
}
