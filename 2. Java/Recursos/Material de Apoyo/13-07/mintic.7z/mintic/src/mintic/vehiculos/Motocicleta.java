package mintic.vehiculos;

import javax.swing.text.View;

/**
 *
 * @author farma
 */
public class Motocicleta extends Combustion implements IElectrico{

    @Override
    public void EjemploClaseAbstract(String ejemplo) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean pruebElectrico(Vehiculo vehiculo, Motocicleta motocicleta) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void testeoComponentes(String parametro) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void onClick(View view) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    
}
